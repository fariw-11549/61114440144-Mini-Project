package com.chaiwatnakub.herbsthai;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;


public class Main6Activity extends AppCompatActivity {

    MediaPlayer song;

    private void SenToIn(int sherb) {

        String[] selected = {"ดาหลา","กระเจี๊ยบมอญ","ผักเหนาะ","ตะลิงปลิง"};

        Intent intent = new Intent(Main6Activity.this, ShowMainActivity.class);
        intent.putExtra("herbName", selected[sherb]);
        startActivity(intent);


    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);

        song = MediaPlayer.create(Main6Activity.this, R.raw.c);

        ScrollView scrollView = new ScrollView(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        scrollView.setLayoutParams(layoutParams);

        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams linearParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setLayoutParams(linearParams);
        scrollView.addView(linearLayout);



        String[] southern = {"dahla","kajaeb","pagnoa","talingping"};


        for(int i=0;i<southern.length;i++){

            ImageView imageView1 = new ImageView(this);
            LinearLayout.LayoutParams params1 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            params1.setMargins(0, 30, 0, 30);
            params1.gravity = Gravity.CENTER;
            imageView1.setLayoutParams(params1);

            //ดึงภาพ จาก drawable
            int id = getResources().getIdentifier(southern[i], "drawable", getPackageName());
            imageView1.setImageResource(id);
            linearLayout.addView(imageView1);

            final int finalI = i;
            imageView1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    SenToIn(finalI);
                }
            });
        }

        TextView home = new TextView(this);
        LinearLayout.LayoutParams homeparams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
        homeparams.setMargins(350, 30, 350, 30);
        homeparams.gravity = Gravity.CENTER;
        home.setBackgroundResource(R.drawable.button);
        home.setGravity(Gravity.CENTER);
        home.setTextColor(Color.DKGRAY);
        home.setText(R.string.rolback);
        home.setTextSize(35);
        Typeface typeface = Typeface.createFromAsset(getAssets(), "main.ttf");
        home.setTypeface(typeface);
        home.setLayoutParams(homeparams);
        linearLayout.addView(home);
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent back = new Intent(Main6Activity.this, Main2Activity.class);
                startActivity(back);
                song.start();
                finish();


            }
        });


        LinearLayout linear_end = findViewById(R.id.southern_herbs);
        if (linear_end != null) {
            linear_end.addView(scrollView);
        }
    }
}