package com.chaiwatnakub.herbsthai;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class Main2Activity extends AppCompatActivity {

    MediaPlayer song;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        song = MediaPlayer.create(Main2Activity.this, R.raw.c);



        Button north = (Button)findViewById(R.id.north);
        north.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent next1 = new Intent(Main2Activity.this, Main3Activity.class);
                startActivity(next1);
                song.start();
                finish();
            }
        });





        Button central = (Button)findViewById(R.id.central);
        central.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent next2 = new Intent(Main2Activity.this, Main4Activity.class);
                startActivity(next2);
                song.start();
                finish();
            }
        });

        Button northeast = (Button)findViewById(R.id.northeast);
        northeast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent next3 = new Intent(Main2Activity.this, Main5Activity.class);
                startActivity(next3);
                song.start();
                finish();
            }
        });

        Button southern = (Button)findViewById(R.id.southern);
        southern.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent next4 = new Intent(Main2Activity.this, Main6Activity.class);
                startActivity(next4);
                song.start();
                finish();
            }
        });

        Button exit = (Button)findViewById(R.id.exit);
        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent exit = new Intent(Intent.ACTION_MAIN);
                exit.addCategory(Intent.CATEGORY_HOME);
                exit.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(exit);
                song.start();
                finish();
            }
        });

    }
}
