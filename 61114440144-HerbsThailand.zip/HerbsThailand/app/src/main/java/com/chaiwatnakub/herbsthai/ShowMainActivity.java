package com.chaiwatnakub.herbsthai;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.content.Intent;




public class ShowMainActivity extends AppCompatActivity {
    MediaPlayer song;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_main);

        song = MediaPlayer.create(ShowMainActivity.this, R.raw.c);

        Intent intent = getIntent();
        String herbName = intent.getStringExtra("herbName");

        ScrollView show_scroll = new ScrollView(this);
        LinearLayout.LayoutParams show_params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        show_scroll.setLayoutParams(show_params);

        LinearLayout showmain = new LinearLayout(this);
        LinearLayout.LayoutParams main_params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        showmain.setOrientation(LinearLayout.VERTICAL);
        showmain.setLayoutParams(main_params);
        show_scroll.addView(showmain);



        ImageView image_herb = new ImageView(this);
        LinearLayout.LayoutParams im_params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        im_params.setMargins(0, 30, 0, 30);
        im_params.gravity = Gravity.CENTER;
        image_herb.setLayoutParams(im_params);


        TextView textherb = new TextView(this);
        LinearLayout.LayoutParams herb = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        herb.setMargins(60, 30, 60, 60);
        herb.gravity = Gravity.CENTER;
        textherb.setTextColor(Color.BLACK);
        Typeface typeface1 = Typeface.createFromAsset(getAssets(), "Quark-Bold.otf");
        textherb.setTypeface(typeface1);
        textherb.setTextSize(22);
        textherb.setLayoutParams(herb);



        TextView nameherb = new TextView(this);
        LinearLayout.LayoutParams text = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        text.setMargins(0, 30, 0, 30);
        text.gravity = Gravity.CENTER;
        nameherb.setText(herbName);
        nameherb.setTextSize(28);
        nameherb.setTypeface(typeface1);
        nameherb.setTextColor(Color.BLACK);
        nameherb.setGravity(Gravity.CENTER);
        nameherb.setLayoutParams(text);





        if(herbName.equals("บวบเหลี่ยม")){
        textherb.setText(R.string.text_bueb);
        image_herb.setImageResource(R.drawable.baub);
    }
        if(herbName.equals("ชะพลู")){
        image_herb.setImageResource(R.drawable.chapoo);
        textherb.setText(R.string.text_chapoo);
    }
        if(herbName.equals("กระโดน")){
            image_herb.setImageResource(R.drawable.kadon);
            textherb.setText(R.string.text_kadon);
        }
        if(herbName.equals("แคหางป่า")){
            image_herb.setImageResource(R.drawable.kahang);
            textherb.setText(R.string.text_kahang);
        }
        if(herbName.equals("กระเทียม")){
            image_herb.setImageResource(R.drawable.katham);
            textherb.setText(R.string.text_katham);
        }
        if(herbName.equals("กระเทื่อป่า")){
            image_herb.setImageResource(R.drawable.kathur);
            textherb.setText(R.string.text_kathur);
        }
        if(herbName.equals("ค้อนหมาขาว")){
            image_herb.setImageResource(R.drawable.konma);
            textherb.setText(R.string.text_konma);
        }
        if(herbName.equals("โกสน")){
            image_herb.setImageResource(R.drawable.kosron);
            textherb.setText(R.string.text_kosron);
        }


        if(herbName.equals("กล้วยน้ำว้า")){
            image_herb.setImageResource(R.drawable.banana);
            textherb.setText(R.string.text_banana);
        }
        if(herbName.equals("ดอกดิน")){
            image_herb.setImageResource(R.drawable.dogdin);
            textherb.setText(R.string.text_dogdin);
        }
        if(herbName.equals("กระทือ")){
            image_herb.setImageResource(R.drawable.kathu);
            textherb.setText(R.string.text_katua);
        }
        if(herbName.equals("กุ่มน้ำ")){
            image_herb.setImageResource(R.drawable.krum);
            textherb.setText(R.string.text_krum);
        }
        if(herbName.equals("กุยช่าย")){
            image_herb.setImageResource(R.drawable.kuycha);
            textherb.setText(R.string.text_kuycha);
        }
        if(herbName.equals("ตับเต่านา")){
            image_herb.setImageResource(R.drawable.tubtao);
            textherb.setText(R.string.text_tubtao);
        }
        if(herbName.equals("มะอึก")){
            image_herb.setImageResource(R.drawable.maog);
            textherb.setText(R.string.text_maog);
        }
        if(herbName.equals("ขี้กาขาว")){
            image_herb.setImageResource(R.drawable.kakaw);
            textherb.setText(R.string.text_kakaw);
        }


        if(herbName.equals("ผักชีลาว")){
            image_herb.setImageResource(R.drawable.dill);
            textherb.setText(R.string.text_dill);
        }
        if(herbName.equals("ควินิน")){
            image_herb.setImageResource(R.drawable.kawanil);
            textherb.setText(R.string.text_kawinil);
        }
        if(herbName.equals("ข๋อย")){
            image_herb.setImageResource(R.drawable.koul);
            textherb.setText(R.string.text_koul);
        }
        if(herbName.equals("ถั่วแปบ")){
            image_herb.setImageResource(R.drawable.lablab);
            textherb.setText(R.string.text_lablab);
        }
        if(herbName.equals("หอมเป(ผักชีฝรั่ง)")){
            image_herb.setImageResource(R.drawable.linn);
            textherb.setText(R.string.text_linn);
        }
        if(herbName.equals("ขลู่")){
            image_herb.setImageResource(R.drawable.marsh);
            textherb.setText(R.string.text_marsh);
        }
        if(herbName.equals("ผักอีฮีน")){
            image_herb.setImageResource(R.drawable.presl);
            textherb.setText(R.string.text_presl);
        }
        if(herbName.equals("ผักเสี้ยน")){
            image_herb.setImageResource(R.drawable.spider);
            textherb.setText(R.string.text_spider);
        }


        if(herbName.equals("ดาหลา")){
            image_herb.setImageResource(R.drawable.dahla);
            textherb.setText(R.string.text_dahla);
        }
        if(herbName.equals("กระเจี๊ยบมอญ")){
            image_herb.setImageResource(R.drawable.kajaeb);
            textherb.setText(R.string.text_kajaeb);
        }
        if(herbName.equals("ผักเหนาะ")){
            image_herb.setImageResource(R.drawable.pagnoa);
            textherb.setText(R.string.text_pagnoa);
        }
        if(herbName.equals("ตะลิงปลิง")){
            image_herb.setImageResource(R.drawable.talingping);
            textherb.setText(R.string.text_talingping);
        }

        showmain.addView(image_herb);
        showmain.addView(nameherb);
        showmain.addView(textherb);


        TextView home = new TextView(this);
        LinearLayout.LayoutParams homeparams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
        homeparams.setMargins(350, 30, 350, 30);
        homeparams.gravity = Gravity.CENTER;
        home.setBackgroundResource(R.drawable.button);
        home.setGravity(Gravity.CENTER);
        home.setTextColor(Color.DKGRAY);
        home.setText(R.string.back);
        home.setTextSize(35);
        Typeface typeface = Typeface.createFromAsset(getAssets(), "main.ttf");
        home.setTypeface(typeface);
        home.setLayoutParams(homeparams);
        showmain.addView(home);
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                song.start();
                finish();


            }
        });


        LinearLayout linear_end = findViewById(R.id.show_herbs);
            if (linear_end != null) {
            linear_end.addView(show_scroll);
        }
    }
}
